package com.programacion.distribuida.dto;

import lombok.Data;

@Data
public class AuthorDto {

    private Integer id;
    private String firstName;
    private String lastName;

}
