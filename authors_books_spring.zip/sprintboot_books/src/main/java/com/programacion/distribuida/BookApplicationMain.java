package com.programacion.distribuida;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookApplicationMain {
    public static void main(String[] args) {
        SpringApplication.run(BookApplicationMain.class, args);
    }
}
