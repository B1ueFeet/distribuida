package com.programacion.distribuida;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthorsApplicationMain {
    public static void main(String[] args) {
        SpringApplication.run(AuthorsApplicationMain.class, args);
    }
}
